# animal_shelter.py

from pymongo import MongoClient

class AnimalShelter:
    def __init__(self, username="aacuser", password="aacpassword"):
        # Connect to MongoDB
        self.client = MongoClient(f"mongodb://{username}:{password}@nv-desktop-services.apporto.com:31534/?authSource=admin&directConnection=true")
        self.database = self.client["AAC"]
        self.collection = self.database["animals"]

    def create(self, data):
        if data:
            insert_result = self.collection.insert_one(data)
            return True if insert_result.acknowledged else False
        else:
            raise Exception("Nothing to save, data is empty")

    def read(self, query, limit=0):
        if limit > 0:
            return list(self.collection.find(query).limit(limit))
        else:
            return list(self.collection.find(query))

    def update(self, query, new_data):
        update_result = self.collection.update_many(query, {"$set": new_data})
        return update_result.modified_count

    def delete(self, query):
        delete_result = self.collection.delete_many(query)
        return delete_result.deleted_count

